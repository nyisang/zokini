<?php

 include 'DatabaseConfig.php';
 
 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);

$result = mysqli_query($con,"SELECT *from newuser WHERE name='" . $id . "'");
$row=mysqli_fetch_array($result);

 $Sql_Query  = "UPDATE newuser set password='" . $_POST["password"] . "' WHERE name='" . $id . "'";
if(mysqli_query($con,$Sql_Query)){
 
 echo 'Password changed Successfully';
 
 }
 else{
 
 echo 'No such Phone Number in our database';
 
 }
 mysqli_close($con);

?>