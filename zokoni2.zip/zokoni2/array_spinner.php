<?php
include 'DatabaseConfig.php';
// Create connection
$con = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);

$sql = "SELECT * FROM location";


$r = mysqli_query($con,$sql);

$result = array();

while($row = mysqli_fetch_array($r)){
    array_push($result,array(
        'id'=>$row['id'],
        'adminlocation'=>$row['adminlocation'],
       
    ));
}

echo json_encode(array('result'=>$result));

mysqli_close($con);
?>




