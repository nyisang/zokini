<?php
include 'DatabaseConfig.php';
 
function getLocation(){
  $db = new DbConnect();
    //$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
    // array for json response
    $response = array();
    $response["location"] = array();
     
    // Mysql select query
    $result = mysqli_query("SELECT * FROM location");
     
    while($row = mysqli_fetch_array($result)){
        // temporary array to create single category
        $tmp = array();
        $tmp["id"] = $row["id"];
        $tmp["adminlocation"] = $row["adminlocation"];
         
        // push category to final json array
        array_push($response["location"], $tmp);
    }
     
    // keeping response header to json
    header('Content-Type: application/json');
     
    // echoing json result
    echo json_encode($response);
}
 
getLocation();
?>