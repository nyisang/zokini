<?php

include 'DatabaseConfig.php';

// Create connection
$conn = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);
 
 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
 $DefaultId = 0;


 //$ImageName = $_POST['image_name'];
 $adminproduct = $_POST['adminproduct'];
 $adminproductdescription = $_POST['adminproductdescription'];
 $adminproductprice = $_POST['adminproductprice'];
 $adminproductoffer = $_POST['adminproductoffer'];
 $adminproductquantity = $_POST['adminproductquantity'];
 $admincategory = $_POST['admincategory'];

 $ImageData = $_POST['image_path'];
 //$adminproductimage = $_POST['adminproductimage'];


 $GetOldIdSQL ="SELECT id FROM newproduct ORDER BY id ASC";
 
 $Query = mysqli_query($conn,$GetOldIdSQL);
 
 while($row = mysqli_fetch_array($Query)){
 
 $DefaultId = $row['id'];
 }
 
 $ImagePath = "images/$DefaultId.png";
 
 
 $ServerURL = "http://192.168.43.13:81/zokoni2/images/$ImagePath";
 					
  $Sql_Query = "insert into newproduct (adminproduct,adminproductdescription,adminproductprice,adminproductoffer, adminproductquantity, admincategory,image_path) 
 values ('$adminproduct','$adminproductdescription','$adminproductprice','$adminproductoffer','$adminproductquantity','$admincategory','$ServerURL')";
 
 if(mysqli_query($conn,  $Sql_Query)){

 file_put_contents($ImagePath,base64_decode($ImageData));

 echo "Your Image Has Been Uploaded.";
 }
 
 mysqli_close($conn);
 }else{
 echo "Not Uploaded";
 }

?>