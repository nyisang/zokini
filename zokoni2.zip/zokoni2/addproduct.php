<?php

    if($_SERVER['REQUEST_METHOD']=='POST'){
        $adminproduct = $_POST['adminproduct'];
        $adminproductdescription = $_POST['adminproductdescription'];
        $adminproductprice = $_POST['adminproductprice'];
        $adminproductoffer = $_POST['adminproductoffer'];
        $adminproductquantity = $_POST['adminproductquantity'];
        $admincategory = $_POST['admincategory'];
        $image1 = $_POST['image1'];
     

      include 'DatabaseConfig.php';

        $sql ="SELECT id FROM newproduct ORDER BY id ASC";

        $res = mysqli_query($con,$sql);

         $id = uniqid();

        while($row = mysqli_fetch_array($res)){
                $id = $row['id'];
        }

      
                $path1 = "images/".uniqid().".png";

        
        $actualpath1  = "http://192.168.43.13:81/zokoni2/images/$path1";

        $sql = "INSERT INTO newproduct (adminproduct,adminproductdescription,adminproductprice,adminproductoffer,adminproductquantity,admincategory,image1) 
		VALUES ('$adminproduct','$adminproductdescription','$adminproductprice','$adminproductoffer','$adminproductquantity','$admincategory','$actualpath1')";

        if(mysqli_query($con,$sql)){
                        file_put_contents($path1,base64_decode($image1));
            echo "Successfully Uploaded";
        }

        mysqli_close($con);
    }else{
        echo "Error";
    }
?>