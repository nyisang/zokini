<?php

include 'DatabaseConfig.php' ;
 
 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
 
 $name = $_POST['name'];
 $spinnerlocation = $_POST['spinnerlocation'];
 $address = $_POST['address'];
 $phone = $_POST['phone'];
 $estate = $_POST['estate'];
 $house = $_POST['house'];
 $password = $_POST['password'];


 
 $Sql_Query = "insert into newuser ( name,spinnerlocation, address,phone,estate, house, password) 
 values ('$name', '$spinnerlocation', '$address', '$phone', '$estate','$house', '$password')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>

